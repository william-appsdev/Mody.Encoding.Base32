﻿# Mody's Base32 Encoding
Mody's Base32 Encoding is an encoding technology, used for .NET 5 or later, developed and maintained by Mody Technology.
